<?php

return[

'home_menu'=>'Home',
'about_menu'=>'About Us',
'course_menu'=>'Courses',
'accommodation_menu'=>'Accommodation',
'blog_menu'=>'Blog',
'contact_us'=>'Contact Us',
'search'=>'Search',
'city'=>'City',
'login'=>'Login',
'logout'=>'Logout',
'register'=>'Register',
'refer_friend'=>'Refer a friend',
'budget'=>'Budget',
'course_type'=>'Course Type',
'select_city'=>'Select City',
'search_title'=>'Find a Language Course',
'course_length'=>'Course Length',
'week'=>'Week',
'search_heading'=>'Discover course in your budget.',
'enter_budget'=>'Enter budget',
'search_course'=>'Search Course',
'define_course_goal'=>'Define Course Goal',
'analysis_scope_in_market'=>'Analysis Scope in Market',
'choose_a_date'=>'Choose a date',
'prepare_fly'=> 'Prepare & Fly',

];
