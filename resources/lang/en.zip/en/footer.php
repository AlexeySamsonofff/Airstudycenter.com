<?php

return[
'about_us'=>'About Us',
'popular_post'=>'Popular Post',
'quick_link'=>'Quick Links',
'partner'=>'Partner',
'school'=>'School',
'accommodation'=>'Accommodation',
'office'=>'Office',
'about_us_detail'=>"It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout' Content here, content here', making it look like readable English",
'copy_right'=>'© 2018 Air Study Center. All Rights Reserved',
'signin'=>'Sign In',
'email'=>'Email',
'password'=>'Password',
'email'=>'Email',
'remember_me'=>'Remember me',
'forgot_password'=>'Forget Password?',
'sign_up'=>'Sign Up',
'not_a_member'=>'Not a member yet?',
'c_password'=>'Confirm Password',
'agree_term_condition'=>'I agree to the Terms and Conditions',
'register_now'=>'Register Now',
'continue_with'=>'or continue with',
'facebook'=>'Facebook',
'google'=>'Google',
'sign_in_here'=>'Sign In Here',
'already_member'=>'Already member yet? ',
'get_new_password'=>'Get New Password',
'name'=>'Name',


];


