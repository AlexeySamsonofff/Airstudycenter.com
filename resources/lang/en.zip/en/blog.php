<?php
return[
'blog'=>'Blog',
'home'=>'Home',
'search'=>'Search',
'categories'=>'Categories',
'recent'=>'Recent Post',
'readmore'=>'Read More',
'comment'=>'Comment',
'leavecomment'=>'Leave a Comment',
'postcomment'=>'Post Comment',
];