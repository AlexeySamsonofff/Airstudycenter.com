<?php
return[
'contactus'=>'Contact Us',
'name_form'=>'Your Name',
'email_form'=>'Your Email Id',
'phone_form'=>'Phone',
'subject_form'=>'Subject',
'message_form'=>'Your Message',
'quick'=>'Quick Contact',
'address'=>'ADDRESS',
'email' =>'EMAIL',
'phone' =>'PHONE',
'submit'=>'Submit',
];