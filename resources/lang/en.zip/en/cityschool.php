<?php

return[

'london_high_school'=>'London Language School',
'home'=>'Home',
'city'=>'City',
'course_name'=>'Course Name',
'length_of_course'=>'Length of Course',
'ppw'=>'Price per week ',
'Book'=>'BOOK',
'book'=>'Book',
'hpw'=>'hours / Week',
'years'=>'years',

];