<?php
return[
'discounted'=>'Discounted',
'courses'=>'Courses',
'discountedtext'=>'Learning English:one thing that will be heavily discounted is not a physical product.Instead you can give or get educationla courses and start on your new career,learning resolutions early.',
'popular'=>'Popular',
'cities'=>'Cities',
'populartext'=>'Find the best English school at the best price.Quality comparison,reviews and special offers on adult group courses for learning English in the United Kingdom.',
'premium'=>'Premium Language',
'schools'=>'Schools',
'premiumtext'=>'Premium Ranking of Language School Destinatons Cities Ranked by popularity according to our students.Click on a country or city for a list of language schools,evaluations and booking.',
'allcities'=>'View All Cities',
'allschool'=>'View All Schools',
'allcourses'=>'View All Course',
'ourtestimonials'=>'Our Testimonials',
'topcourses'=>'Top Courses',
'review'=>'Review',
'years'=>'years',
];